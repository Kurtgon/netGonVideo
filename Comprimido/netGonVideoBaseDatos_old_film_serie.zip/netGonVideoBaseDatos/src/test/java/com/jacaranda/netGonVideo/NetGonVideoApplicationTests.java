package com.jacaranda.netGonVideo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetGonVideoApplicationTests {

	@Test
	void contextLoads() {
	}

}
